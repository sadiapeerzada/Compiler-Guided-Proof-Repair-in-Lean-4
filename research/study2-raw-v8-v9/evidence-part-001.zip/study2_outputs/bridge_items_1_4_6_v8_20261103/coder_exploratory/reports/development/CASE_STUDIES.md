# Automatically selected illustrative case studies (successes first, then sorted remaining cases)

These contain raw local model output and compiler errors; check privacy/licensing before publication.

## bridge_d01 / mlx-community/Qwen2.5-Coder-7B-Instruct-4bit / seed 2027

Initial verifier: verified

Initial compiler diagnostics:
```text

```

```lean
theorem bridge_d01 (a b : Nat) : a + b = b + a :=
by rw [add_comm]
```

### B_neutral — True
### C_real — True
### D_shuffled — True
### E_token_matched — True
### R_resample — True
## bridge_d02 / mlx-community/Qwen2.5-Coder-7B-Instruct-4bit / seed 2027

Initial verifier: unknown_name

Initial compiler diagnostics:
```text
line 11: Unknown identifier `add.assoc`
line 11: unsolved goals
a b c : ℕ
⊢ a + b + c = a + (b + c)
```

```lean
theorem bridge_d02 (a b c : Nat) : (a + b) + c = a + (b + c) :=
by rw [add.assoc]
```

### B_neutral — False
Repair B_neutral_1, verifier unknown_name
```lean
theorem bridge_d02 (a b c : Nat) : (a + b) + c = a + (b + c) :=
by rw [add.assoc]
```

Compiler diagnostics:
```text
line 11: Unknown identifier `add.assoc`
line 11: unsolved goals
a b c : ℕ
⊢ a + b + c = a + (b + c)
```

Repair B_neutral_2, verifier unknown_name
```lean
theorem bridge_d02 (a b c : Nat) : (a + b) + c = a + (b + c) :=
by rw [add.assoc]
```

Compiler diagnostics:
```text
line 11: Unknown identifier `add.assoc`
line 11: unsolved goals
a b c : ℕ
⊢ a + b + c = a + (b + c)
```

Repair B_neutral_3, verifier unknown_name
```lean
theorem bridge_d02 (a b c : Nat) : (a + b) + c = a + (b + c) :=
by rw [add.assoc]
```

Compiler diagnostics:
```text
line 11: Unknown identifier `add.assoc`
line 11: unsolved goals
a b c : ℕ
⊢ a + b + c = a + (b + c)
```

### C_real — False
Repair C_real_1, verifier unknown_name
```lean
theorem bridge_d02 (a b c : Nat) : (a + b) + c = a + (b + c) :=
by rw [Nat.add.assoc]
```

Compiler diagnostics:
```text
line 11: Unknown constant `Nat.add.assoc`
line 11: unsolved goals
a b c : ℕ
⊢ a + b + c = a + (b + c)
```

Repair C_real_2, verifier unknown_name
```lean
theorem bridge_d02 (a b c : Nat) : (a + b) + c = a + (b + c) :=
by rw [add.assoc]
```

Compiler diagnostics:
```text
line 11: Unknown identifier `add.assoc`
line 11: unsolved goals
a b c : ℕ
⊢ a + b + c = a + (b + c)
```

Repair C_real_3, verifier unknown_name
```lean
theorem bridge_d02 (a b c : Nat) : (a + b) + c = a + (b + c) :=
by rw [add.assoc]
```

Compiler diagnostics:
```text
line 11: Unknown identifier `add.assoc`
line 11: unsolved goals
a b c : ℕ
⊢ a + b + c = a + (b + c)
```

### D_shuffled — False
Repair D_shuffled_1, verifier unknown_name
```lean
theorem bridge_d02 (a b c : Nat) : (a + b) + c = a + (b + c) :=
by rw [add.assoc]
```

Compiler diagnostics:
```text
line 11: Unknown identifier `add.assoc`
line 11: unsolved goals
a b c : ℕ
⊢ a + b + c = a + (b + c)
```

Repair D_shuffled_2, verifier unknown_name
```lean
theorem bridge_d02 (a b c : Nat) : (a + b) + c = a + (b + c) :=
by rw [add.assoc]
```

Compiler diagnostics:
```text
line 11: Unknown identifier `add.assoc`
line 11: unsolved goals
a b c : ℕ
⊢ a + b + c = a + (b + c)
```

Repair D_shuffled_3, verifier unknown_name
```lean
theorem bridge_d02 (a b c : Nat) : (a + b) + c = a + (b + c) :=
by rw [add.assoc]
```

Compiler diagnostics:
```text
line 11: Unknown identifier `add.assoc`
line 11: unsolved goals
a b c : ℕ
⊢ a + b + c = a + (b + c)
```

### E_token_matched — False
Repair E_token_matched_1, verifier unknown_name
```lean
theorem bridge_d02 (a b c : Nat) : (a + b) + c = a + (b + c) :=
by rw [add.assoc]
```

Compiler diagnostics:
```text
line 11: Unknown identifier `add.assoc`
line 11: unsolved goals
a b c : ℕ
⊢ a + b + c = a + (b + c)
```

Repair E_token_matched_2, verifier unknown_name
```lean
theorem bridge_d02 (a b c : Nat) : (a + b) + c = a + (b + c) :=
by rw [add.assoc]
```

Compiler diagnostics:
```text
line 11: Unknown identifier `add.assoc`
line 11: unsolved goals
a b c : ℕ
⊢ a + b + c = a + (b + c)
```

Repair E_token_matched_3, verifier unknown_name
```lean
theorem bridge_d02 (a b c : Nat) : (a + b) + c = a + (b + c) :=
by rw [add.assoc]
```

Compiler diagnostics:
```text
line 11: Unknown identifier `add.assoc`
line 11: unsolved goals
a b c : ℕ
⊢ a + b + c = a + (b + c)
```

### R_resample — False
Repair R_resample_1, verifier unknown_name
```lean
import Mathlib

theorem bridge_d02 (a b c : Nat) : (a + b) + c = a + (b + c) :=
by rw [add.assoc]
```

Compiler diagnostics:
```text
line 12: Unknown identifier `add.assoc`
line 12: unsolved goals
a b c : ℕ
⊢ a + b + c = a + (b + c)
```

Repair R_resample_2, verifier unknown_name
```lean
theorem bridge_d02 (a b c : Nat) : (a + b) + c = a + (b + c) :=
by rw [add.assoc]
```

Compiler diagnostics:
```text
line 11: Unknown identifier `add.assoc`
line 11: unsolved goals
a b c : ℕ
⊢ a + b + c = a + (b + c)
```

Repair R_resample_3, verifier unknown_name
```lean
theorem bridge_d02 (a b c : Nat) : (a + b) + c = a + (b + c) :=
by rw [add.assoc]
```

Compiler diagnostics:
```text
line 11: Unknown identifier `add.assoc`
line 11: unsolved goals
a b c : ℕ
⊢ a + b + c = a + (b + c)
```

## bridge_d03 / mlx-community/Qwen2.5-Coder-7B-Instruct-4bit / seed 2027

Initial verifier: verified

Initial compiler diagnostics:
```text

```

```lean
theorem bridge_d03 (a : Nat) : a + 0 = a :=
by rw [Nat.add_zero]
```

### B_neutral — True
### C_real — True
### D_shuffled — True
### E_token_matched — True
### R_resample — True