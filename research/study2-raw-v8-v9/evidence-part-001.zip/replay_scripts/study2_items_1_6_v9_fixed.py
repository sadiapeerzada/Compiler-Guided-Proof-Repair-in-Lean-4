#!/usr/bin/env python3
"""Study 2 follow-up for supervisor corrections 1 and 6.

1: exploratory error-aware Lean repair arm, using the Coder model's EXISTING
   frozen initial candidates and at most three fresh repair calls.
6: cryptographically check V8 evidence, re-screen 24 reference proofs, create
   an explicit adjudication worksheet for independent AI flags/duplicate pairs.

No existing experiment, original benchmark, or manuscript is edited. Existing
V8 test outcomes have already been inspected: any further test is EXPLORATORY.
"""
from __future__ import annotations
import argparse, csv, datetime, difflib, hashlib, importlib.util, json, os, re, sys
from collections import Counter
from pathlib import Path

V7_SHA = 'a5cc110d387331e9aaf4a2909c52a3cf9a87c5a6daa9feadf01eb5b438359edc'
V8 = Path('study2_outputs/bridge_items_1_4_6_v8_20261103')
V7_BASE = Path('study2_outputs/bridge_v7_base')
OUT = Path('study2_outputs/bridge_items_1_6_v9_exploratory')
MODEL = 'mlx-community/Qwen2.5-Coder-7B-Instruct-4bit'
SEEDS = (2027, 2028, 2029)
POLICY = 'error-aware-fixed-v1; 3 repairs max; fixed prompt progression; no theorem-specific answer hints'
ALLOWED_ITEM = {'ACCEPT_FORMAL_ONLY', 'REJECT_FORMAL_TASK', 'UNRESOLVED'}
ALLOWED_PAIR = {'DISTINCT', 'NEAR_DUPLICATE', 'UNRESOLVED'}


def sha(p:Path):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for buf in iter(lambda:f.read(1024*1024),b''):h.update(buf)
    return h.hexdigest()

def hashtext(s):return hashlib.sha256(s.encode('utf-8')).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def fail(msg):raise RuntimeError(msg)
def require(ok,msg):
    if not ok:fail(msg)
def put(p,x):
    p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists():fail(f'Refusing overwrite: {p}')
    with p.open('x',encoding='utf-8') as f:
        json.dump(x,f,indent=2,sort_keys=True,ensure_ascii=False);f.write('\n');f.flush();os.fsync(f.fileno())

def csvrows(path):
    with path.open(newline='',encoding='utf-8') as f:return list(csv.DictReader(f))

def writerows(path, rows, headers):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=headers);writer.writeheader();writer.writerows(rows);f.flush();os.fsync(f.fileno())


def load_v7(root):
    path=root/'study2_supervisor_suite_v7.py'
    require(path.is_file() and sha(path)==V7_SHA,
            'Frozen V7 source missing or changed; use original Mac research checkout')
    spec=importlib.util.spec_from_file_location('frozen_v7_for_study_1_6',path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    return mod


def verify_v8(root):
    lockfile=root/V8/'FINAL_1_4_6_LOCK.json'
    require(lockfile.is_file(),'V8 evidence lock missing: '+str(lockfile))
    lock=read(lockfile);files=lock.get('data_hashes',[])
    require(len(files)>=35,'V8 manifest unexpectedly small')
    for item in files:
        rel=Path(item['path'])
        require(not rel.is_absolute() and '..' not in rel.parts,'Unsafe lock path')
        p=root/rel
        require(p.is_file(),f'Archived evidence missing: {rel}')
        require(sha(p)==item['sha256'],f'V8 hash mismatch: {rel}; STOP, do not modify')
        if 'bytes' in item:require(p.stat().st_size==item['bytes'],f'V8 size mismatch: {rel}')
    require(lock.get('do_not_edit_frozen_v7') is True,'Lock unexpectedly permits V7 edits')
    return lock


def audit(root,mod,output,recheck_lean=False):
    lock=verify_v8(root)
    mod.root_check(need_curated=False)
    mod.set_lean_profile('bridge-minimal')
    tests=mod.bridge_rows('test');dev=mod.bridge_rows('development')
    require(len(tests)==24 and len(dev)==12,'Unexpected benchmark cardinality')
    tests_by={r['id']:r for r in tests}
    plan=read(root/V8/'coder_exploratory/plan.json')
    require(plan['script_sha256']==V7_SHA,'Unexpected Coder experiment script revision')
    require(plan['seeds']==list(SEEDS) and list(plan['models'])==[MODEL], 'Different Coder model/seeds')
    # V8 froze the deterministic category-round-robin selection, not the
    # source-order list returned by bridge_rows('test').  The cohort and
    # its SHA-pinned V7 generator stay untouched.
    frozen_order = mod.chosen_test(tests, len(tests))
    require(plan['rows']['test']==[r['id'] for r in frozen_order],
            'V8 test selection/order disagrees with the frozen V7 selector')
    reviewp=root/V8/'ai_review/AI_REVIEW_RAW.jsonl'
    reviews=[json.loads(line) for line in reviewp.read_text(encoding='utf-8').splitlines() if line.strip()]
    require(len(reviews)==24 and {x['id'] for x in reviews}==set(tests_by),'Reviewer record count/IDs mismatch')
    flags=[]
    for r in reviews:
        x=r.get('parsed') or {}
        if (r.get('status')!='PARSED' or x.get('coherence')!='PASS' or x.get('family_label')!='PASS'
            or x.get('suspected_near_duplicate_ids')):flags.append(r['id'])
    summary=read(root/V8/'ai_review/AI_REVIEW_SUMMARY.json')
    require(sorted(flags)==summary['flag_or_uncertain_ids'],'AI summary and actual reviews disagree')
    bench=read(root/V8/'validation/BENCHMARK_AUDIT.json')
    similar=bench.get('near_duplicates_HEURISTIC',[])
    cross=bench.get('cross_split_similarity_HEURISTIC',[])
    require(bench['test_count']==24 and bench['development_count']==12,'Unexpected benchmark audit')
    def normalized(t):
        return re.sub(r'\s+','',re.sub(r'theorem\s+\w+','theorem',t))
    predicted_test=[]
    for i,a in enumerate(tests):
        for b in tests[i+1:]:
            ratio=difflib.SequenceMatcher(None,normalized(a['expected_lean_statement']),
                                             normalized(b['expected_lean_statement'])).ratio()
            if ratio>=0.80:predicted_test.append((a['id'],b['id']))
    predicted_cross=[]
    for a in dev:
        for b in tests:
            ratio=difflib.SequenceMatcher(None,normalized(a['expected_lean_statement']),
                                             normalized(b['expected_lean_statement'])).ratio()
            if ratio>=0.80:predicted_cross.append((a['id'],b['id']))
    require(set(predicted_test)=={(p['a'],p['b']) for p in similar},
            'Saved within-test similarity audit disagrees with recomputation')
    require(set(predicted_cross)=={(p['development'],p['test']) for p in cross},
            'Saved cross-split similarity audit disagrees with recomputation')
    if recheck_lean:
        print('Rechecking 24 STRICT Lean reference proofs (may take time)...',flush=True)
        rec=mod.reference_screen(root,tests,output/'independent_lean_screen')
        require(len(rec)==24 and all(r.get('constructed_reference_proof_kernel_verified') is True
                                     and r.get('lean_statement_elaborates') is True for r in rec),
                'Fresh strict Lean screen did not pass all 24 references')
    else:
        print('Recorded strict Lean checks are hash-verified; use --recheck-lean to run fresh checks.')

    rows=[]
    reviewed={r['id']:r for r in reviews}
    for id in sorted(flags):
        x=reviewed[id];parsed=x.get('parsed') or {}
        rows.append({'type':'AI_FLAG','left':id,'right':'',
            'reason':json.dumps({'coherence':parsed.get('coherence'),'family':parsed.get('family_label'),
                'duplicates':parsed.get('suspected_near_duplicate_ids'),
                'rationale':parsed.get('rationale')},ensure_ascii=False),
            'decision':'UNRESOLVED','justification':''})
    for item in similar:
        rows.append({'type':'WITHIN_TEST_PAIR','left':item.get('a',''),'right':item.get('b',''),
                     'reason':'heuristic similarity '+str(item.get('character_similarity','')),
                     'decision':'UNRESOLVED','justification':''})
    for item in cross:
        rows.append({'type':'CROSS_SPLIT_PAIR','left':item.get('development',''),'right':item.get('test',''),
                     'reason':'heuristic similarity '+str(item.get('character_similarity','')),
                     'decision':'UNRESOLVED','justification':''})
    worksheet=output/'VALIDATION_DECISIONS.csv'
    if not worksheet.exists():
        writerows(worksheet,rows,['type','left','right','reason','decision','justification'])
    else:
        existing=csvrows(worksheet)
        require({(x['type'],x['left'],x['right']) for x in existing}==
                {(x['type'],x['left'],x['right']) for x in rows},'Worksheet identities changed')
    cases=[]
    for t in tests:
        id=t['id'];ai=reviewed[id]
        cases.append({'id':id,'theorem':t['expected_lean_statement'],
                      'reference_proof':t['reference_lean_proof'],
                      'english_description':t['nl_statement'],
                      'formal_reference_proof_sha256':hashtext(t['reference_lean_proof']),
                      'reviewer_model':ai.get('model'), 'reviewer_parsed':ai.get('parsed'),
                      'reviewer_raw_response':ai.get('raw_response'),
                      'ai_flag':id in flags})
    casepath=output/'VALIDATION_CASES.json'
    if not casepath.exists():put(casepath,cases)
    else:require(read(casepath)==cases,'Validation case packet does not match frozen review')
    base=csvrows(root/V7_BASE/'reports/test/outcomes.csv')
    coder=csvrows(root/V8/'coder_exploratory/reports/test/outcomes.csv')
    require(len(base)==len(coder)==72,'Frozen outcome denominator mismatch')
    record={'version':'items-1-6-v9','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'v8_lock_sha256':sha(root/V8/'FINAL_1_4_6_LOCK.json'),
            'number_of_v8_hashes_verified':len(lock['data_hashes']),
            'strict_lean_rechecked':bool(recheck_lean),
            'strict_lean_recorded_passing':24,
            'ai_records':24,'ai_flags':sorted(flags),
            'similar_within_test_count':len(similar),'similar_cross_split_count':len(cross),
            'base_model_C_successes':sum(x['C_real']=='True' for x in base),
            'coder_model_C_successes':sum(x['C_real']=='True' for x in coder),
            'english_to_lean_semantics':'UNASSESSABLE: benchmark has placeholder English',
            'known_test_reuse':'The 24 theorems and outcomes were already observed; any V9 test is post-hoc exploratory',
            'training_contamination':'UNKNOWN','benchmark_originals_untouched':True}
    p=output/'SOURCE_AUDIT.json'
    if p.exists():
        previous=read(p)
        for key in record:
            if key not in ('created_at','strict_lean_rechecked'):
                require(previous.get(key)==record[key],f'V9 source audit mismatch: {key}')
        if recheck_lean and not previous.get('strict_lean_rechecked'):
            # preserve first audit; fresh screen files provide separate immutable evidence
            pass
    else:put(p,record)
    print('AUDIT: all',len(lock['data_hashes']),'manifest files verified; 24 Lean screens recorded;'
          f' {len(flags)} AI flags; {len(similar)} within-test and {len(cross)} cross-split pairs')
    print('EDIT DECISIONS: ',worksheet)
    return record


def check_adjudications(output):
    rows=csvrows(output/'VALIDATION_DECISIONS.csv')
    unresolved=[];reject=[]
    require(rows,'No review worksheet rows')
    for r in rows:
        allowed=ALLOWED_ITEM if r['type']=='AI_FLAG' else ALLOWED_PAIR
        require(r['decision'] in allowed,'Invalid decision for '+r['left'])
        if r['decision']=='UNRESOLVED' or not r['justification'].strip():unresolved.append(r)
        if r['decision'] in ('REJECT_FORMAL_TASK','NEAR_DUPLICATE'):reject.append(r)
    return {'total':len(rows),'unresolved':len(unresolved),'serious_flags':len(reject),
            'unresolved_keys':[(r['type'],r['left'],r['right']) for r in unresolved],
            'english_faithfulness':'NOT_EVALUABLE_WITH_PLACEHOLDER'}


def stage_prompt(row,prior,verification,step,mod):
    theorem=row['expected_lean_statement']
    err=mod.diagnostic(verification) or 'Compiler returned no structured error. Inspect the previous attempt.'
    err=err[:1200]
    head=('You are repairing a Lean 4 proof of EXACTLY this theorem. '
          'Keep declaration, binders, types, and theorem name unchanged. '
          'Return only a single fenced ```lean block with a complete theorem. '
          'NO sorry, admit, axiom, opaque, helper declarations, or imports. '
          'Never use a reference solution. Available tactics depend on the goal.\n\n'
          'Fixed theorem:\n```lean\n'+theorem+'\n```\n')
    if step==1:
        instruction=('First correct syntax and type-elaboration errors in the prior attempt. '
                     'For arithmetic consider omega; for polynomial identities consider ring; '
                     'for propositional tautologies consider tauto or constructor/intros; '
                     'for definitional equalities consider rfl. Apply tactics ONLY if valid.\n')
    elif step==2:
        instruction=('Write a fresh complete proof rather than repeating a failing candidate. '
                     'Use the simplest correct Lean 4 tactic or a short structured proof. '
                     'Do not depend on any changes to the statement.\n')
    else:
        instruction=('Final attempt: choose an independent concise proof strategy. '
                     'Use Lean standard tactics conservatively. Do not repeat a known failed proof.\n')
    return head+instruction+'\nPrevious candidate:\n```lean\n'+prior[:3000]+'\n```\nCompiler diagnostics:\n'+err+'\n'


def run_phase(root,mod,output,split,allow_inference):
    require(allow_inference,'Explicitly pass --approve-inference for real model calls')
    # Do not run against an edited or mismatched V8 snapshot.
    verify_v8(root)
    mod.root_check(need_curated=False);mod.set_lean_profile('bridge-minimal')
    plan=read(root/V8/'coder_exploratory/plan.json')
    identity=plan['models'][MODEL]
    require(Path(identity['path']).exists(),'Pinned Coder snapshot no longer on disk')
    # Local snapshot identity is checked BEFORE generating.
    model_identity=mod.model_identity(Path(identity['path']),MODEL)
    require(model_identity==identity,'Coder weights/config mismatch versus frozen V8 identity')
    model=mod.MLXModel(Path(identity['path']),MODEL,identity,
                       int(plan['max_context']),int(plan['max_output']),float(plan['temperature']))
    rows=mod.bridge_rows('development' if split=='development' else 'test')
    if split=='test':
        # Replay the exact predeclared V8 test order. Never infer a new order
        # or filter by success, difficulty, flags, or reviewer outcomes.
        rows=mod.chosen_test(rows, len(rows))
        require([r['id'] for r in rows]==plan['rows']['test'],
                'Test order no longer matches the frozen Coder plan')
    else:
        require([r['id'] for r in rows]==plan['rows']['development'],
                'Development order no longer matches the frozen Coder plan')
    seeds=(2027,) if split=='development' else SEEDS
    model_key=mod.safe_key(MODEL.split('/')[-1])
    source=root/V8/'coder_exploratory'
    dest=output/'new_repair_arm'
    policy_record={'policy':POLICY,'policy_sha256':hashtext(POLICY+stage_prompt.__code__.co_code.hex()),
                   'reference_v7_script_sha256':V7_SHA,'v8_lock_sha256':sha(root/V8/'FINAL_1_4_6_LOCK.json'),
                   'launcher_sha256':sha(Path(__file__).resolve()),
                   'base_model':MODEL,'benchmark':'bridge','lean_profile':'bridge-minimal',
                   'seeds':list(seeds),'split':split,'repair_budget':3,
                   'source_initials':'UNCHANGED frozen V8 Coder outputs',
                   'retrospective':'This test cohort already appeared in V8; no confirmatory hypothesis claim.'}
    phase_plan=dest/(split+'_plan.json')
    if not phase_plan.exists():put(phase_plan,policy_record)
    else:require(read(phase_plan)==policy_record,'Frozen follow-up plan mismatch')
    report=dest/(split+'_results.json')
    if report.exists():
        print('Existing completed results:',report)
        return read(report)
    all_results=[]
    try:
        for seed in seeds:
            for row in rows:
                initial=mod.load_initial(source,model_key,seed,split,row)
                require(initial is not None and initial['state']=='complete' and initial.get('verification'),
                        'Missing COMPLETE frozen initial for '+str((split,seed,row['id'])))
                init_success=bool(initial['verification']['success'])
                status='initial_verified' if init_success else 'budget_exhausted'
                prior=initial;outcome=init_success;steps=[]
                for step in range(1,4):
                    if outcome:break
                    if prior.get('state')!='complete' or not prior.get('verification'):
                        status='previous_unavailable';outcome=None;break
                    if prior['verification'].get('failure_kind') in ('infrastructure_error','timeout','verifier_error','input_error'):
                        status='verifier_unavailable';outcome=None;break
                    previous=mod.get_previous(prior) or ''
                    prompt=stage_prompt(row,previous,prior['verification'],step,mod)
                    ctx='V9-1-6/'+hashtext(POLICY)[:12]+'/'+split+'/'+str(seed)+'/'+row['id']+'/'+str(step)
                    current=mod.run_step(dest,root,model,row,seed,model_key,split,
                                         'v9_error_aware_'+str(step),prompt,ctx,
                                         extra={'source_initial':'V8_Coder','step':step})
                    steps.append({'step':step,'state':current['state'],
                                  'verification_success':(current.get('verification') or {}).get('success'),
                                  'key':current.get('key')})
                    if current['state']!='complete' or not current.get('verification'):
                        status='incomplete';outcome=None;break
                    prior=current
                    if current['verification']['success']:
                        status='verified';outcome=True
                all_results.append({'id':row['id'],'seed':seed,'category':row['category'],
                                    'initial_success':init_success,'new_arm_success':outcome,
                                    'status':status,'steps':steps})
                print(f'{split} {seed} {row["id"]}: {status}',flush=True)
    finally:
        model.unload()
    planned=len(rows)*len(seeds)
    require(len(all_results)==planned,'Unexpected incomplete phase result set')
    frozen=csvrows(source/'reports'/split/'outcomes.csv')
    original={(r['id'],int(r['seed'])):r for r in frozen}
    require(set(original)=={(r['id'],r['seed']) for r in all_results},'Baseline paired IDs not matched')
    stable=sum(original[(r['id'],r['seed'])]['C_real']=='True' for r in all_results)
    success=sum(r['new_arm_success'] is True for r in all_results)
    unknown=sum(r['new_arm_success'] is None for r in all_results)
    new_only=sum(r['new_arm_success'] is True and
                 original[(r['id'],r['seed'])]['C_real']=='False' for r in all_results)
    guided_only=sum(r['new_arm_success'] is False and
                    original[(r['id'],r['seed'])]['C_real']=='True' for r in all_results)
    initial_rescues=sum(r['new_arm_success'] is True and not r['initial_success'] for r in all_results)
    result={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'planned':planned,'new_arm_verified':success,
            'original_v8_coder_guided_verified':stable,'new_arm_minus_v8_guided':success-stable,
            'paired_new_only':new_only,'paired_guided_only':guided_only,
            'new_arm_rescues_after_failed_initial':initial_rescues,
            'unknown_outcomes':unknown,'retrospective':'Test previously observed: exploratory only',
            'records':all_results}
    put(report,result)
    print('RESULT:',split,'new=',success,'/',planned,'V8-Coder guided=',stable,'/',planned,'unknown=',unknown)
    return result


def finalize(root,out):
    decisions=check_adjudications(out)
    dev=out/'new_repair_arm/development_results.json'
    test=out/'new_repair_arm/test_results.json'
    stats={}
    for label,path in [('development',dev),('test',test)]:
        if path.exists():
            x=read(path)
            stats[label]={k:x[k] for k in ('planned','new_arm_verified','original_v8_coder_guided_verified',
                                           'new_arm_minus_v8_guided','unknown_outcomes',
                                           'paired_new_only','paired_guided_only','new_arm_rescues_after_failed_initial')}
    assessment={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'item1':{'experiments':stats,'verdict':'EXPLORATORY; success improvement must be observed, not guaranteed'},
                'item6':{'adjudication':decisions,'verdict':('FORMAL VALIDATION REVIEWED; NL SEMANTICS UNTESTED'
                   if decisions['unresolved']==0 and decisions['serious_flags']==0 else 'NOT FULLY VALIDATED')},
                'recommendation':'Preserve V7/V8/V9 as separate studies; do not replace V8 results or claim NL→Lean faithfulness',
                'sha256':{str(p.relative_to(root)):sha(p) for p in [root/V8/'FINAL_1_4_6_LOCK.json',
                       root/'study2_supervisor_suite_v7.py',out/'VALIDATION_DECISIONS.csv',out/'VALIDATION_CASES.json']}}
    name=out/'FINAL_ITEMS_1_6_ASSESSMENT.json'
    if name.exists():
        require({k:v for k,v in read(name).items() if k!='created_at'}==
                {k:v for k,v in assessment.items() if k!='created_at'},
                'Earlier final assessment exists; do not silently overwrite it')
    else:put(name,assessment)
    print(json.dumps({'item1':assessment['item1'],'item6':assessment['item6']},indent=2))
    print('Written:',name)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('mode',choices=['audit','dev','test','finalize','self-test'])
    ap.add_argument('--repo',type=Path,default=Path.home()/'NLP-to-Formal-Language-Proof')
    ap.add_argument('--recheck-lean',action='store_true',help='Fresh STRICT Lean verification for all 24 references')
    ap.add_argument('--approve-inference',action='store_true',help='Explicitly authorize local model generation')
    ap.add_argument('--approve-exploratory-test',action='store_true',help='Acknowledge V8 test outcomes already seen')
    ap.add_argument('--allow-low-signal',action='store_true',help='Proceed with test despite no development gain; disclose')
    args=ap.parse_args()
    if args.mode=='self-test':
        require(len(SEEDS)==3 and hashtext('a')==hashlib.sha256(b'a').hexdigest(),'Self-test failed')
        class Stub:
            @staticmethod
            def diagnostic(v):return None
        require(stage_prompt({'expected_lean_statement':'theorem t : True'},'theorem t : True := by trivial',{},1,Stub).find('theorem t : True')>=0,'Prompt test failed')
        print('PASS: static self-tests only (no Lean/model/evidence checks)');return
    root=args.repo.expanduser().resolve()
    require(root.is_dir(),'Missing repository: '+str(root))
    os.chdir(root)
    out=root/OUT
    mod=load_v7(root)
    if args.mode=='audit':
        audit(root,mod,out,recheck_lean=args.recheck_lean)
    elif args.mode in ('dev','test'):
        require((out/'VALIDATION_CASES.json').exists(), 'Run audit first to verify frozen evidence')
        audit(root,mod,out,recheck_lean=False)
        if args.mode=='test':
            require(args.approve_exploratory_test,'Pass --approve-exploratory-test; this reused test is NOT held out')
            path=out/'new_repair_arm/development_results.json'
            require(path.exists(),'Run dev FIRST; never tune on test')
            dev=read(path)
            require(dev['unknown_outcomes']==0,'Development has missing outcomes; test blocked')
            if dev['new_arm_minus_v8_guided']<=0 and not args.allow_low_signal:
                fail('NO-GO: dev did not improve over frozen Coder guided. To run exploratory test despite failure, use --allow-low-signal.')
        run_phase(root,mod,out,'development' if args.mode=='dev' else 'test',args.approve_inference)
    else:
        require((out/'VALIDATION_DECISIONS.csv').exists(),'Run audit before finalizing')
        verify_v8(root)
        finalize(root,out)

if __name__=='__main__':
    try:main()
    except (KeyboardInterrupt,SystemExit):raise
    except Exception as exc:
        print('STOPPED: '+type(exc).__name__+': '+str(exc),file=sys.stderr)
        sys.exit(2)
