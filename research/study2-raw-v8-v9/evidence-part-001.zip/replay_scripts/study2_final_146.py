#!/usr/bin/env python3
"""Study 2 final gates for checklist items 1, 4 and 6.

A NEW, post-hoc exploratory Coder-model experiment, independent AI mathematical
review, and strict Lean reference validation. Never edits frozen V7 outcomes.

Mac: .venv-study2/bin/python ~/Downloads/study2_final_146.py run \
       --repo ~/NLP-to-Formal-Language-Proof --approve-inference --approve-downloads

Python 3.10+; Apple Silicon, pinned Lean/Mathlib and the V7 MLX environment
are required for the actual inference/Lean phases. Status is offline and safe.
"""
from __future__ import annotations
import argparse
import csv
import difflib
import gc
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone

BASE = 'study2_outputs/bridge_v7_base'
WORK = 'study2_outputs/bridge_items_1_4_6_v8_20261103'
CODER = WORK + '/coder_exploratory'
SCREEN = WORK + '/reference_screen'
REVIEW = WORK + '/ai_review'
TEST_MODEL = 'mlx-community/Qwen2.5-Coder-7B-Instruct-4bit'
REVIEWER = 'mlx-community/Phi-4-mini-instruct-4bit'
V7_SHA = 'a5cc110d387331e9aaf4a2909c52a3cf9a87c5a6daa9feadf01eb5b438359edc'
ARMS = ('B_neutral','C_real','D_shuffled','E_token_matched','R_resample')
SEEDS = (2027,2028,2029)
# Published 17-file archive hashes, independently recomputed from the uploaded V7 ZIP.
# These stop a modified original from being silently treated as the original V7 study.
BASE_HASHES = {
 'plan.json':'e41704c03e8b2d84b959fdf84afd343d505739d45845ee9cfbdb8afc2d057009',
 'reports/test/outcomes.csv':'e766a98ae53830e748da273aaace3ff958e15d53dd72cd92387f25928a3cc72a',
 'reports/test/calls.csv':'b8cdd830a38b6fe052835d050674831101037aced2663947248096620dd47293',
 'reports/test/transitions.csv':'e6bd5d5973971e957e6adf13c023f505798b96edf53f36464fa4f0232fe2fef1',
 'reports/test/summary.json':'20e7da2aec11c251a2f2364980134fc2bbaf13f5916ecbc2a536a8f29f9faae3',
 'reports/test/REPORT.md':'00208b82551157319e72844741cb748dcbd4a58d8b2d7696d4c850848d9f1e8b',
}



def now():
    return datetime.now(timezone.utc).isoformat()

def sha(p:Path):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(2*1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def htxt(s):return hashlib.sha256(s.encode('utf-8')).hexdigest()

def json_read(p):return json.loads(p.read_text(encoding='utf-8'))

def json_write_new(p,obj):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8') as f:
        json.dump(obj,f,indent=2,ensure_ascii=False,sort_keys=True)
        f.write('\n'); f.flush();os.fsync(f.fileno())

def csv_read(p):
    with p.open('r',encoding='utf-8',newline='') as f:
        return list(csv.DictReader(f))

def require(ok,reason):
    if not ok: raise RuntimeError(reason)

def import_v7(repo):
    file=repo/'study2_supervisor_suite_v7.py'
    require(file.is_file(),'V7 script missing: '+str(file))
    require(sha(file)==V7_SHA,'V7 source differs from frozen SHA-256. Do not run changed code.')
    spec=importlib.util.spec_from_file_location('frozen_study2_v7',file)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def inspect_base(repo,mod):
    base=repo/BASE
    require((base/'plan.json').is_file(),'Frozen base plan missing: '+str(base/'plan.json')+' (use your ORIGINAL Mac repo, not the clean Git worktree)')
    for rel,want in BASE_HASHES.items():
        original=base/rel
        require(original.is_file() and sha(original)==want,
                'Frozen original evidence does not match audited artifact: '+rel)
    p=json_read(base/'plan.json')
    require(p.get('script_sha256')==V7_SHA,'Base plan uses a different V7 source')
    require(p.get('benchmark')=='bridge' and p.get('lean_profile')=='bridge-minimal','Unexpected frozen benchmark/profile')
    require(p.get('seeds')==list(SEEDS),'Frozen seed mismatch')
    ids=p.get('rows',{}).get('test',[])
    require(len(ids)==24 and set(ids)=={r['id'] for r in mod.bridge_rows('test')},'Unexpected benchmark test set')
    require(len(p.get('models',{}))==1 and 'mlx-community/Qwen2.5-7B-Instruct-4bit' in p['models'],'Frozen V7 study must be one base model')
    for rel,recorded in p.get('source_files',{}).items():
        q=repo/rel
        require(q.is_file() and sha(q)==recorded,'Frozen source dependency missing/modified: '+rel)
    rows=csv_read(base/'reports/test/outcomes.csv')
    require(len(rows)==72,'Base results must contain 72 rows')
    require({(x['id'],int(x['seed'])) for x in rows}=={(i,s) for i in ids for s in SEEDS},'Base theorem-seed identities incomplete/duplicated')
    require(all(x.get(a) in ('True','False') for x in rows for a in ARMS),'Base model has unresolved arm outcomes')
    counts={'A':sum(x['initial_success']=='True' for x in rows)}
    for arm in ARMS:counts[arm]=sum(x[arm]=='True' for x in rows)
    require(counts=={'A':4,'B_neutral':5,'C_real':10,'D_shuffled':9,'E_token_matched':5,'R_resample':5},'Base outcomes differ from audited V7 snapshot')
    calls=csv_read(base/'reports/test/calls.csv')
    require(len(calls)==1078,'Frozen call count differs from audited V7')
    require(len(csv_read(base/'reports/test/transitions.csv'))==1006,'Frozen transition count differs from audited V7')
    print('PASS: immutable base evidence',counts, 'calls=1078; repairs=1006')
    return p,rows

def benchmark_audit(repo,mod,save=True):
    dev=mod.bridge_rows('development'); test=mod.bridge_rows('test')
    require(len(dev)==12 and len(test)==24,'Constructed study has unexpected size')
    ids=[x['id'] for x in test]
    require(len(set(ids))==24,'Duplicate theorem IDs')
    deff={mod.family(x) for x in dev}; testf={mod.family(x) for x in test}
    require(not (deff & testf),'Development and test families overlap')
    ordered=[]
    for row in dev+test:
        ordered.append({'id':row['id'],'family':mod.family(row),'category':row['category'],
                        'theorem_sha256':htxt(row['expected_lean_statement']),
                        'reference_sha256':htxt(row['reference_lean_proof'])})
    tests={x['id']:x['expected_lean_statement'] for x in test}
    def normalized(t):
        # Heuristic comparison, not semantic equivalence or model-training overlap proof.
        return re.sub(r'\s+','',re.sub(r'theorem\s+\w+', 'theorem',t))
    similarities=[]
    for idx,a in enumerate(ids):
        for b in ids[idx+1:]:
            ratio=difflib.SequenceMatcher(None,normalized(tests[a]),normalized(tests[b])).ratio()
            if ratio>=0.80:
                similarities.append({'a':a,'b':b,'character_similarity':round(ratio,4)})
    cross_split=[]
    for dr in dev:
        for tr in test:
            ratio=difflib.SequenceMatcher(None,normalized(dr['expected_lean_statement']),
                                          normalized(tr['expected_lean_statement'])).ratio()
            if ratio>=0.80:
                cross_split.append({'development':dr['id'],'test':tr['id'],
                                    'character_similarity':round(ratio,4)})
    output={'created_at':now(),'benchmark':'bridge constructed proof tasks','development_count':12,'test_count':24,
            'family_disjoint':True,'test_families':sorted(testf),'test_categories':dict(Counter(r['category'] for r in test)),
            'near_duplicates_HEURISTIC':sorted(similarities,key=lambda z:-z['character_similarity']),
            'cross_split_similarity_HEURISTIC':sorted(cross_split,key=lambda z:-z['character_similarity']),
            'records':ordered,'english_semantics':'NOT_EVALUABLE_FROM_PLACEHOLDER',
            'external_training_overlap':'UNKNOWN; cannot establish from string checking',
            'caution':'Post-hoc audit of test set already used in V7; no outcome-based deletions.'}
    if save:
        out=repo/WORK/'validation'
        p=out/'BENCHMARK_AUDIT.json'
        if p.exists():require(json_read(p)['records']==ordered,'Existing benchmark audit disagrees with current source')
        else:json_write_new(p,output)
    print(f"PASS: 12 dev / 24 test, disjoint families. Possible within-test near duplicates: {len(similarities)}; dev/test similarities: {len(cross_split)} (review required)")
    return output

def runner(repo,mod,phase,out,approve_downloads=False,force_study=False):
    python=repo/'.venv-study2/bin/python'
    require(python.is_file(),'Missing .venv-study2 Python: '+str(python))
    script=repo/'study2_supervisor_suite_v7.py'
    cmd=[str(python),str(script),'--mode',phase,'--models','coder','--benchmark','bridge',
         '--lean-profile','bridge-minimal','--out',str(out.relative_to(repo)),
         '--seeds',','.join(map(str,SEEDS)),'--dev-seeds','2027']
    if approve_downloads and phase!='screen-test':cmd.append('--download-models')
    if force_study and phase=='study':cmd.append('--force-study')
    print('RUN:', ' '.join(cmd),flush=True)
    subprocess.run(cmd,cwd=repo,check=True)

def strict_screen(repo,mod):
    path=repo/SCREEN
    if len(list((path/'reference_screen').glob('bridge_t[0-9][0-9].json')))!=24:
        # A distinct output folder is required; no test-model inference is triggered.
        runner(repo,mod,'screen-test',path)
    result=[]
    for row in mod.bridge_rows('test'):
        p=path/'reference_screen'/(row['id']+'.json')
        require(p.exists(),'Reference-screen checkpoint missing: '+str(p))
        x=json_read(p)
        require(x.get('id')==row['id'] and x.get('constructed_reference_proof_kernel_verified') is True
                and x.get('lean_statement_elaborates') is True,
                'Strict Lean reference validation failed for '+row['id'])
        result.append({'id':x['id'],'sha256':sha(p),'proof_verified':True})
    print('PASS: strict Lean kernel reference checks 24/24 (formal correctness only)')
    return result


def reviewer_inputs(mod):
    tests=mod.bridge_rows('test')
    context='\n'.join(f"{r['id']}: {r['expected_lean_statement']}" for r in tests)
    for r in tests:
        payload={'id':r['id'],'category':r['category'],'family':mod.family(r),
                 'formal_statement':r['expected_lean_statement'],
                 'reference_proof':r['reference_lean_proof'],
                 'english_statement':r['nl_statement'],
                 'all_test_formal_statements':context}
        yield payload

def parse_json_object(raw):
    text=raw.strip()
    if '```' in text:
        m=re.search(r'```(?:json)?\s*(\{.*?\})\s*```',text,re.S)
        if m:text=m.group(1)
    try:
        val=json.loads(text)
        if isinstance(val,dict):return val
    except (json.JSONDecodeError,ValueError):pass
    st=text.find('{');en=text.rfind('}')
    if st>=0 and en>st:
        try:
            val=json.loads(text[st:en+1]);return val if isinstance(val,dict) else None
        except (json.JSONDecodeError,ValueError):pass
    return None

def review_prompt(x):
    return ("You are an INDEPENDENT, SKEPTICAL REVIEWER of a constructed Lean 4 proof task. "
            "This is NOT a natural-language translation evaluation: English text is a generic placeholder. "
            "Do not infer faithful NL→Lean translation or pretraining cleanliness. The strict Lean kernel, "
            "not this language model, establishes proof verification. Give an independent mathematical "
            "assessment, possible ambiguity, and exact duplicate/near-duplicate theorem IDs. "
            "Return ONLY a JSON object with keys: coherence (PASS|FLAG|UNCERTAIN), "
            "reference_proof_comment (string), suspected_near_duplicate_ids (array of IDs), "
            "family_label (PASS|FLAG|UNCERTAIN), difficulty (1|2|3|4), "
            "limitations (string), rationale (string). Be conservative and flag concerns.\n\n"
            +json.dumps(x,ensure_ascii=False,sort_keys=True))

def run_ai_review(repo,mod,approve_downloads=False):
    """Actually call a distinct, local MLX reviewer, journal full prompts/responses."""
    from huggingface_hub import snapshot_download
    from mlx_lm import load,generate
    review_dir=repo/REVIEW
    review_dir.mkdir(parents=True,exist_ok=True)
    journal=review_dir/'AI_REVIEW_RAW.jsonl'
    snapshots=review_dir/'REVIEWER_MODEL.json'
    if snapshots.exists():
        meta=json_read(snapshots)
        require(meta.get('model')==REVIEWER,'Existing reviewer model differs')
        path=Path(meta['local_snapshot'])
        require(path.exists(),'Previous reviewer model snapshot no longer present')
    else:
        path=Path(snapshot_download(REVIEWER,local_files_only=not approve_downloads))
        meta={'model':REVIEWER,'local_snapshot':str(path.resolve()),'snapshot_revision':path.resolve().name,
              'created_at':now(),'library':'mlx_lm','purpose':'independent model-based mathematical coherence review; NOT English semantic faithfulness'}
        json_write_new(snapshots,meta)
    done={}
    if journal.exists():
        for line in journal.read_text(encoding='utf-8').splitlines():
            if not line.strip():continue
            record=json.loads(line)
            require(record['id'] not in done,'Duplicate review journal id: '+record['id'])
            done[record['id']]=record
    tasks=list(reviewer_inputs(mod))
    for task in tasks:
        if task['id'] in done:
            require(done[task['id']]['prompt_sha256']==htxt(review_prompt(task)),
                    'Existing AI review prompt mismatched for '+task['id'])
    pending=[x for x in tasks if x['id'] not in done]
    if pending:
        print(f'Loading independent reviewer {REVIEWER}; {len(pending)} remaining')
        model,tok=load(str(path),tokenizer_config={'trust_remote_code':False})
        for idx,task in enumerate(pending,1):
            prompt=review_prompt(task)
            rendered=tok.apply_chat_template([{'role':'user','content':prompt}],tokenize=False,add_generation_prompt=True)
            raw=generate(model,tok,rendered,max_tokens=400,verbose=False)
            parsed=parse_json_object(raw)
            allowed={'PASS','FLAG','UNCERTAIN'}
            state='PARSED' if isinstance(parsed,dict) and parsed.get('coherence') in allowed and parsed.get('family_label') in allowed else 'UNPARSEABLE'
            attempts=[{'prompt_sha256':htxt(prompt),'raw_response':raw}]
            if state!='PARSED':
                # At most one format-only retry. Original model output is retained verbatim.
                followup=prompt+'\n\nIMPORTANT: reply as one valid JSON object only; keys must match exactly.'
                rerendered=tok.apply_chat_template([{'role':'user','content':followup}],tokenize=False,add_generation_prompt=True)
                second=generate(model,tok,rerendered,max_tokens=500,verbose=False)
                attempts.append({'prompt_sha256':htxt(followup),'raw_response':second})
                candidate=parse_json_object(second)
                if isinstance(candidate,dict) and candidate.get('coherence') in allowed and candidate.get('family_label') in allowed:
                    raw=second;parsed=candidate;state='PARSED'
            record={'id':task['id'],'created_at':now(),'model':REVIEWER,'snapshot_revision':meta['snapshot_revision'],
                    'prompt_sha256':htxt(prompt),'prompt':prompt,'raw_response':raw,'raw_response_sha256':htxt(raw),
                    'attempts':attempts,'parsed':parsed,'status':state,'english_to_lean_faithfulness':'NOT_EVALUABLE_FROM_PLACEHOLDER',
                    'original_inference_results_unchanged':True}
            with journal.open('a',encoding='utf-8') as f:
                f.write(json.dumps(record,sort_keys=True,ensure_ascii=False)+'\n');f.flush();os.fsync(f.fileno())
            done[task['id']]=record
            print(f"AI REVIEW {idx}/{len(pending)} {task['id']}: {state} / {parsed.get('coherence') if isinstance(parsed,dict) else 'no JSON'}",flush=True)
        del model,tok
        gc.collect()
    require(len(done)==24,'Independent AI review incomplete')
    flags=[r['id'] for r in done.values() if r['status']!='PARSED' or r['parsed'].get('coherence')!='PASS' or r['parsed'].get('family_label')!='PASS' or r['parsed'].get('suspected_near_duplicate_ids')]
    summary={'model':REVIEWER,'snapshot':meta['snapshot_revision'],'records':len(done),'flag_or_uncertain_ids':sorted(flags),
             'english_semantics':'NOT_EVALUABLE_FROM_PLACEHOLDER',
             'interpretation':'AI opinions are triage only; not gold annotations, not Lean proof verification; duplicate concerns require review.'}
    p=review_dir/'AI_REVIEW_SUMMARY.json'
    if p.exists():
        prev=json_read(p)
        require(prev['flag_or_uncertain_ids']==summary['flag_or_uncertain_ids'],'AI review changed after prior summary; do not overwrite')
    else:json_write_new(p,summary)
    print('PASS: actual independent reviewer calls persisted 24/24; flags:',len(flags))
    return summary


def verify_ai_review(repo,mod):
    folder=repo/REVIEW
    journal=folder/'AI_REVIEW_RAW.jsonl'
    summary_file=folder/'AI_REVIEW_SUMMARY.json'
    require(journal.exists() and summary_file.exists(),'Executed AI reviewer artifacts missing')
    records=[json.loads(x) for x in journal.read_text(encoding='utf-8').splitlines() if x.strip()]
    expected={r['id'] for r in mod.bridge_rows('test')}
    require(len(records)==24 and {x['id'] for x in records}==expected,'AI reviewer journal must have 24 unique theorem IDs')
    flags=[]
    tasks={x['id']:x for x in reviewer_inputs(mod)}
    for x in records:
        require(x['model']==REVIEWER,'Reviewer model identity unexpectedly changed')
        require(x['prompt_sha256']==htxt(review_prompt(tasks[x['id']])),
                'AI review prompt was changed for '+x['id'])
        require(x['raw_response_sha256']==htxt(x['raw_response']),
                'AI review raw response changed for '+x['id'])
        p=x.get('parsed') or {}
        if x.get('status')!='PARSED' or p.get('coherence')!='PASS' or p.get('family_label')!='PASS' or p.get('suspected_near_duplicate_ids'):
            flags.append(x['id'])
    summ=json_read(summary_file)
    require(summ.get('records')==24 and summ.get('flag_or_uncertain_ids')==sorted(flags),'AI reviewer summary does not match raw records')
    print('PASS: actual independent reviewer records verified (24/24)')
    return summ


def experiment(repo,mod,approve_downloads=False,allow_low_signal=False):
    out=repo/CODER
    dev=out/'reports/development/summary.json'
    test=out/'reports/test/summary.json'
    if not dev.exists():
        print('Starting NEW Coder-only development calibration: NOT a V7 overwrite')
        runner(repo,mod,'dev',out,approve_downloads)
    ds=json_read(dev)
    require(ds.get('cases')==12 and ds.get('planned_cases')==12,'Coder development cases incomplete')
    data=csv_read(out/'reports/development/outcomes.csv')
    require(len(data)==12,'Coder development missing outcomes')
    failed=sum(x['initial_success']=='False' for x in data)
    rescued=sum(x['initial_success']=='False' and (x['B_neutral']=='True' or x['C_real']=='True') for x in data)
    waived=failed==0 or rescued==0
    if waived and not allow_low_signal:
        raise RuntimeError('NO-GO: Coder dev floor gate not met (no failed initials or no B/C rescues). '
                           'Frozen dev data preserved; test NOT automatically launched. To record an explicit exploratory waiver, use --allow-low-signal.')
    if waived:
        waiver=out/'LOW_SIGNAL_WAIVER.json'
        if not waiver.exists():
            json_write_new(waiver,{'created_at':now(),'failed_initials':failed,'dev_rescues':rescued,
                        'warning':'Explicit post-hoc exploratory continuation; not a positive development gate.'})
        print('WARNING: low-signal development waiver recorded. No improvement claim is allowed.')
    if not test.exists() or json_read(test).get('cases_terminal')!=72:
        print('Starting separate Coder test protocol; exploratory='+str(waived))
        runner(repo,mod,'study',out,approve_downloads,force_study=waived)
    return inspect_coder(repo,mod)

def inspect_coder(repo,mod):
    out=repo/CODER
    p=out/'plan.json';q=out/'reports/test/outcomes.csv'
    require(p.exists() and q.exists(),'Coder experiment not complete')
    plan=json_read(p)
    require(plan.get('script_sha256')==V7_SHA and plan.get('benchmark')=='bridge'
            and plan.get('lean_profile')=='bridge-minimal','Coder used a different protocol')
    require(list(plan.get('models',{}))==[TEST_MODEL],'Coder plan must contain ONLY Coder model')
    require(plan.get('seeds')==list(SEEDS),'Coder seeds differ')
    require(len(plan.get('rows',{}).get('test',[]))==24,'Coder test theorem count differs')
    rows=csv_read(q)
    require(len(rows)==72,'Coder test is incomplete: '+str(len(rows))+'/72')
    keys={(x['id'],int(x['seed'])) for x in rows}
    require(keys=={(r['id'],s) for r in mod.bridge_rows('test') for s in SEEDS},'Coder theorem-seed identities incomplete or duplicated')
    require(all(x.get(a) in ('True','False') for x in rows for a in ARMS),'Coder test contains missing model-arm outcomes')
    counts={'A':sum(r['initial_success']=='True' for r in rows)}
    for a in ARMS:counts[a]=sum(r[a]=='True' for r in rows)
    print('PASS: completed additional-model experiment (post-hoc exploratory):',counts)
    return counts


def freeze(repo,mod,baseplan):
    audit=benchmark_audit(repo,mod,save=True)
    screens=strict_screen_verify_only(repo,mod)
    review=verify_ai_review(repo,mod)
    coder=inspect_coder(repo,mod)
    base={'A':4,'B_neutral':5,'C_real':10,'D_shuffled':9,'E_token_matched':5,'R_resample':5}
    curated=[]
    for base_dir,patterns in [(repo/BASE,['plan.json','reports/test/outcomes.csv','reports/test/summary.json','reports/test/calls.csv','reports/test/transitions.csv']),
                             (repo/CODER,['plan.json','reports/development/outcomes.csv','reports/development/summary.json',
                                          'reports/test/outcomes.csv','reports/test/summary.json','reports/test/calls.csv','reports/test/transitions.csv']),
                             (repo/REVIEW,['AI_REVIEW_RAW.jsonl','AI_REVIEW_SUMMARY.json','REVIEWER_MODEL.json'])]:
        for rel in patterns:
            file=base_dir/rel
            require(file.is_file(),'Missing archive component: '+str(file))
            curated.append({'path':str(file.relative_to(repo)),'sha256':sha(file),'bytes':file.stat().st_size})
    for s in screens:curated.append({'path':str((repo/SCREEN/'reference_screen'/(s['id']+'.json')).relative_to(repo)), 'sha256':s['sha256']})
    source=repo/'study2_supervisor_suite_v7.py'
    curated.append({'path':str(source.relative_to(repo)), 'sha256':sha(source)})
    status1='OBSERVED_CODER_SUCCESS_HIGHER' if coder['C_real']>base['C_real'] else ('NO_OBSERVED_IMPROVEMENT' if coder['C_real']<=base['C_real'] else 'UNKNOWN')
    status6='PARTIAL__FORMAL_AND_AI_REVIEW_ONLY__NL_SEMANTICS_UNTESTED'
    result={'created_at':now(),'scope':'NEW post-hoc exploratory 2nd-model study; frozen V7 unchanged',
            'item_1':{'status':status1,'base_C':10,'coder_C':coder['C_real'],
                      'warning':'Observed proof success is not guaranteed, a causal mechanism, or a predeclared model-selection win.'},
            'item_4':{'status':'SECOND_MODEL_COMPLETE_EXPLORATORY','base_model':'mlx-community/Qwen2.5-7B-Instruct-4bit','coder_model':TEST_MODEL,
                      'coder_test_cases':72,
                      'low_signal_waiver_used':(repo/CODER/'LOW_SIGNAL_WAIVER.json').is_file()},
            'item_6':{'status':status6,'formal_lean':24,'ai_reviewed':24,'possible_heuristic_duplicates':len(audit['near_duplicates_HEURISTIC']),
                      'cross_split_similarities':len(audit['cross_split_similarity_HEURISTIC']),
                      'english_semantics':'NOT_EVALUABLE_FROM_PLACEHOLDER','training_overlap':'UNKNOWN',
                      'human_validation':'NOT_CLAIMED'},
            'comparison':{'base':base,'coder':coder},
            'data_hashes':curated,'do_not_edit_frozen_v7':True,
            'manuscript_caveat':'Use separate-study language; do not reclassify pilot or post-hoc follow-up as an untouched confirmatory evaluation.'}
    p=repo/WORK/'FINAL_1_4_6_LOCK.json'
    if p.exists():
        existing=json_read(p)
        require(existing['data_hashes']==result['data_hashes'],'Existing lock conflicts with current artifacts')
        result=existing
    else:json_write_new(p,result)
    lines=['# Final items 1, 4 and 6 — evidence lock','',
        f"- **1. Improve success:** {result['item_1']['status']} — base C 10/72; Coder C {coder['C_real']}/72. No guaranteed effect.",
        '- **4. Additional models:** executed base and Coder, same theorem cohort/seed set, separate frozen plans; exploratory.',
        f"- **6. Benchmark validation:** 24/24 strict Lean proofs, 24/24 independent AI review calls, {len(review['flag_or_uncertain_ids'])} AI flags and {len(audit['near_duplicates_HEURISTIC'])} heuristic near-duplicate pairs.",
        '- NL-to-Lean semantic equivalence: **not evaluable** because the English text is a placeholder.',
        '- Training contamination: **unknown**. Reviewer-model judgments are not gold.',
        '- Close-to-duplicate items and dev/test similarities are flagged; none were deleted or tuned away.',
        f"- Diagnostic-specific contrast in Coder: real feedback {coder['C_real']}/72 vs shuffled {coder['D_shuffled']}/72; do not claim causal benefit automatically.",
        '- Original V7 CSV, theorem prompts, and reported success counts were not changed.',
        f'- Hash manifest: `{p.name}`','',
        'Do not describe the new Coder runs as pre-registered or as correcting the original 60-theorem floor.']
    md=repo/WORK/'FINAL_1_4_6_REPORT.md'
    if not md.exists():md.write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print('LOCK CREATED:',p)
    print('REPORT:',md)
    print('Frozen original experiment is unchanged. No Git commit or push has been done.')
    return result

def strict_screen_verify_only(repo,mod):
    result=[]
    for row in mod.bridge_rows('test'):
        p=repo/SCREEN/'reference_screen'/(row['id']+'.json')
        require(p.is_file(),'Missing Lean strict-screen record for '+row['id'])
        x=json_read(p)
        require(x.get('constructed_reference_proof_kernel_verified') is True,'Lean screen not verified for '+row['id'])
        result.append({'id':row['id'],'sha256':sha(p)})
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('phase',choices=['check','screen','review','coder','run','lock'],help='run=check+screen+real AI review+Coder+lock')
    p.add_argument('--repo',type=Path,default=Path('~/NLP-to-Formal-Language-Proof'))
    p.add_argument('--approve-inference',action='store_true',help='Explicitly authorize model inference on your Mac')
    p.add_argument('--approve-downloads',action='store_true',help='Permit downloading public MLX model weights (~2.2GB reviewer + ~4.3GB coder)')
    p.add_argument('--allow-review-flags',action='store_true',help='Proceed with Coder exploratory run despite reviewer flags; flags still reported')
    p.add_argument('--allow-low-signal',action='store_true',help='Explicitly waive failed Coder development progress gate; records exploratory waiver')
    args=p.parse_args()
    repo=args.repo.expanduser().resolve()
    require(repo.is_dir(),'Repository not found: '+str(repo))
    mod=import_v7(repo)
    bplan,rows=inspect_base(repo,mod)
    benchmark_audit(repo,mod,save=args.phase!='check')
    if args.phase=='check':
        print('READ-ONLY CHECK PASS. Next run screen or run. Full evaluation not yet complete.');return
    if args.phase in ('screen','review','coder','run'):
        require(args.approve_inference or args.phase=='screen','Model inference requires --approve-inference')
        strict_screen(repo,mod)
    if args.phase in ('review','run'):
        summary=run_ai_review(repo,mod,args.approve_downloads)
        if summary['flag_or_uncertain_ids'] and args.phase=='run' and not args.allow_review_flags:
            raise RuntimeError('AI reviewer has flagged items; Coder experiment paused. Inspect '
                               +str(repo/REVIEW/'AI_REVIEW_SUMMARY.json')+'; use --allow-review-flags only for explicitly exploratory continuation.')
    if args.phase in ('coder','run'):
        require(args.approve_inference,'Coder model inference requires --approve-inference')
        if args.phase=='coder':
            require((repo/REVIEW/'AI_REVIEW_SUMMARY.json').exists(), 'Run actual AI review first (phase review)')
        experiment(repo,mod,args.approve_downloads,args.allow_low_signal)
    if args.phase in ('lock','run'):
        freeze(repo,mod,bplan)

if __name__=='__main__':
    try:main()
    except Exception as e:
        print('STOPPED:',type(e).__name__+':',e,file=sys.stderr)
        sys.exit(2)
